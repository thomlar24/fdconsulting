import { Card } from '@/components/ui/card';
import { Sparkles } from 'lucide-react';

interface DifferentiatorSectionProps {
  language: 'es' | 'en';
}

export default function DifferentiatorSection({ language }: DifferentiatorSectionProps) {
  const content = {
    es: {
      title: 'Nuestro Diferencial',
      description: 'Integramos tecnología de vanguardia con experiencia humana para ofrecer soluciones personalizadas que realmente transforman su negocio. Cada proyecto es único y merece un enfoque adaptado a sus necesidades específicas.'
    },
    en: {
      title: 'Our Differentiator',
      description: 'We integrate cutting-edge technology with human experience to offer personalized solutions that truly transform your business. Each project is unique and deserves an approach tailored to your specific needs.'
    }
  };

  const t = content[language];

  return (
    <section className="py-20 border-b border-border">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground" data-testid="text-differentiator-title">
          {t.title}
        </h2>
        <Card className="p-10 max-w-4xl mx-auto text-center bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <div className="flex justify-center mb-6">
            <Sparkles className="h-16 w-16 text-primary" />
          </div>
          <p className="text-lg text-foreground leading-relaxed" data-testid="text-differentiator-description">
            {t.description}
          </p>
        </Card>
      </div>
    </section>
  );
}
