import { Button } from '@/components/ui/button';
import { ArrowRight, Mail } from 'lucide-react';
import heroImage from '@assets/stock_images/professional_busines_6b33f97a.jpg';

interface HeroSectionProps {
  language: 'es' | 'en';
  onContactClick: () => void;
}

export default function HeroSection({ language, onContactClick }: HeroSectionProps) {
  const content = {
    es: {
      title: 'Organizamos sus datos, optimizamos sus procesos',
      subtitle: 'Consultoría profesional en análisis de datos, contabilidad y gestión de calidad',
      ctaPrimary: 'Contáctenos',
      ctaSecondary: 'Conocer Más'
    },
    en: {
      title: 'We Organize Your Data, Optimize Your Processes',
      subtitle: 'Professional consulting in data analysis, accounting, and quality management',
      ctaPrimary: 'Contact Us',
      ctaSecondary: 'Learn More'
    }
  };

  const t = content[language];

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" className="relative min-h-[85vh] flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img 
          src={heroImage} 
          alt="Professional Consulting" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-[#1B2E49]/90 to-[#1B2E49]/70"></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10 text-center">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 max-w-4xl mx-auto leading-tight">
          {t.title}
        </h1>
        <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto">
          {t.subtitle}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button 
            size="lg" 
            className="bg-primary text-primary-foreground hover:opacity-90 min-w-[200px]"
            onClick={onContactClick}
            data-testid="button-hero-contact"
          >
            <Mail className="mr-2 h-5 w-5" />
            {t.ctaPrimary}
          </Button>
          <Button 
            size="lg" 
            variant="outline" 
            className="bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white/20 min-w-[200px]"
            onClick={() => scrollToSection('services')}
            data-testid="button-hero-learn-more"
          >
            {t.ctaSecondary}
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  );
}
