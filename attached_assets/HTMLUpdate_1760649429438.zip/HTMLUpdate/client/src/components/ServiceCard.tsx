import { LucideIcon } from 'lucide-react';
import { Card } from '@/components/ui/card';

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  items: string[];
}

export default function ServiceCard({ icon: Icon, title, items }: ServiceCardProps) {
  return (
    <Card className="p-6 border-l-4 border-l-primary hover:-translate-y-1 transition-transform duration-300 min-h-[350px] flex flex-col" data-testid={`card-service-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <div className="flex items-center gap-3 mb-4">
        <Icon className="h-12 w-12 text-primary flex-shrink-0" />
        <h3 className="text-xl md:text-2xl font-semibold text-foreground">{title}</h3>
      </div>
      <ul className="space-y-2 flex-1">
        {items.map((item, index) => (
          <li key={index} className="flex items-start gap-2 text-muted-foreground">
            <span className="text-primary font-bold mt-1 flex-shrink-0">✓</span>
            <span className="text-sm md:text-base">{item}</span>
          </li>
        ))}
      </ul>
    </Card>
  );
}
