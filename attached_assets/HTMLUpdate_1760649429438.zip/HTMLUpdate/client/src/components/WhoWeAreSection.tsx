interface WhoWeAreSectionProps {
  language: 'es' | 'en';
}

export default function WhoWeAreSection({ language }: WhoWeAreSectionProps) {
  const content = {
    es: {
      title: '¿Quiénes Somos?',
      description: 'Somos un equipo multidisciplinario de profesionales especializados en transformar datos en información estratégica. Con amplia experiencia en consultoría financiera, análisis de datos y gestión de calidad, ayudamos a empresas a tomar decisiones informadas y optimizar sus procesos operativos.'
    },
    en: {
      title: 'Who We Are?',
      description: 'We are a multidisciplinary team of professionals specialized in transforming data into strategic information. With extensive experience in financial consulting, data analysis, and quality management, we help companies make informed decisions and optimize their operational processes.'
    }
  };

  const t = content[language];

  return (
    <section id="who-we-are" className="py-20 border-b border-border">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-8 text-foreground" data-testid="text-who-we-are-title">
          {t.title}
        </h2>
        <p className="text-lg text-center text-muted-foreground max-w-3xl mx-auto leading-relaxed" data-testid="text-who-we-are-description">
          {t.description}
        </p>
      </div>
    </section>
  );
}
