import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Moon, Sun, Menu, X } from 'lucide-react';
import logoImage from '@assets/9F3EFB34-62E7-49B1-98C6-0DAA78859CA4_1760555172363.png';

interface HeaderProps {
  language: 'es' | 'en';
  onLanguageChange: (lang: 'es' | 'en') => void;
  darkMode: boolean;
  onDarkModeToggle: () => void;
}

export default function Header({ language, onLanguageChange, darkMode, onDarkModeToggle }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  const navItems = language === 'es' 
    ? [
        { id: 'who-we-are', label: 'Quiénes Somos' },
        { id: 'services', label: 'Servicios' },
        { id: 'value-proposition', label: 'Valor' },
        { id: 'contact', label: 'Contacto' }
      ]
    : [
        { id: 'who-we-are', label: 'About Us' },
        { id: 'services', label: 'Services' },
        { id: 'value-proposition', label: 'Value' },
        { id: 'contact', label: 'Contact' }
      ];

  return (
    <header className="sticky top-0 z-50 bg-card border-b border-card-border shadow-sm">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <button 
            onClick={() => scrollToSection('hero')}
            className="hover-elevate rounded-md px-2 py-2"
            data-testid="button-logo"
          >
            <img 
              src={logoImage} 
              alt="Financial & Data Consulting" 
              className="h-20 md:h-28 w-auto"
            />
          </button>

          <nav className="hidden md:flex items-center gap-6">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="text-sm font-semibold text-foreground hover-elevate px-3 py-2 rounded-md transition-colors"
                data-testid={`link-nav-${item.id}`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onLanguageChange(language === 'es' ? 'en' : 'es')}
              className="hidden sm:flex"
              data-testid="button-language-toggle"
            >
              {language === 'es' ? 'EN' : 'ES'}
            </Button>
            
            <Button
              variant="outline"
              size="icon"
              onClick={onDarkModeToggle}
              data-testid="button-dark-mode-toggle"
            >
              {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>

            <Button
              variant="outline"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        {mobileMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 flex flex-col gap-2 border-t border-card-border pt-4">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="text-left text-sm font-semibold text-foreground hover-elevate px-3 py-2 rounded-md"
                data-testid={`link-mobile-nav-${item.id}`}
              >
                {item.label}
              </button>
            ))}
            <Button
              variant="outline"
              size="sm"
              onClick={() => onLanguageChange(language === 'es' ? 'en' : 'es')}
              className="sm:hidden w-full"
              data-testid="button-mobile-language-toggle"
            >
              {language === 'es' ? 'English' : 'Español'}
            </Button>
          </nav>
        )}
      </div>
    </header>
  );
}
