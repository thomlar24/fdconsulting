import { Card } from '@/components/ui/card';
import { Shield, Clock, TrendingUp } from 'lucide-react';

interface ValuePropositionSectionProps {
  language: 'es' | 'en';
}

export default function ValuePropositionSection({ language }: ValuePropositionSectionProps) {
  const content = {
    es: {
      title: 'Nuestra Propuesta de Valor',
      values: [
        {
          icon: Shield,
          title: 'Confiabilidad',
          description: 'Metodologías probadas y resultados medibles'
        },
        {
          icon: Clock,
          title: 'Eficiencia',
          description: 'Optimización de tiempo y recursos empresariales'
        },
        {
          icon: TrendingUp,
          title: 'Crecimiento',
          description: 'Estrategias orientadas al desarrollo sostenible'
        }
      ]
    },
    en: {
      title: 'Our Value Proposition',
      values: [
        {
          icon: Shield,
          title: 'Reliability',
          description: 'Proven methodologies and measurable results'
        },
        {
          icon: Clock,
          title: 'Efficiency',
          description: 'Optimization of time and business resources'
        },
        {
          icon: TrendingUp,
          title: 'Growth',
          description: 'Strategies focused on sustainable development'
        }
      ]
    }
  };

  const t = content[language];

  return (
    <section id="value-proposition" className="py-20 bg-secondary/20 border-b border-border">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground" data-testid="text-value-title">
          {t.title}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {t.values.map((value, index) => (
            <Card key={index} className="p-8 text-center" data-testid={`card-value-${index}`}>
              <div className="flex justify-center mb-4">
                <value.icon className="h-12 w-12 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-foreground">{value.title}</h3>
              <p className="text-muted-foreground">{value.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
