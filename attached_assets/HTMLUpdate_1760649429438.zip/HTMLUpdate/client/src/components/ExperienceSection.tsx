import { Card } from '@/components/ui/card';
import { CheckCircle2 } from 'lucide-react';

interface ExperienceSectionProps {
  language: 'es' | 'en';
}

export default function ExperienceSection({ language }: ExperienceSectionProps) {
  const content = {
    es: {
      title: 'Experiencia',
      items: [
        'Creación de bases de datos y tableros de control para áreas administrativas, contables y operativas.',
        'Implementación de indicadores financieros y de gestión que mejoran la toma de decisiones.',
        'Acompañamiento en procesos de auditoría y cumplimiento normativo.'
      ]
    },
    en: {
      title: 'Experience',
      items: [
        'Creation of databases and dashboards for administrative, accounting, and operational areas.',
        'Implementation of financial and management indicators that improve decision-making.',
        'Support in audit processes and regulatory compliance.'
      ]
    }
  };

  const t = content[language];

  return (
    <section className="py-20 bg-secondary/20 border-b border-border">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground" data-testid="text-experience-title">
          {t.title}
        </h2>
        <Card className="p-8 md:p-12 max-w-4xl mx-auto">
          <ul className="space-y-6">
            {t.items.map((item, index) => (
              <li key={index} className="flex items-start gap-4" data-testid={`text-experience-item-${index}`}>
                <CheckCircle2 className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                <p className="text-base md:text-lg text-foreground leading-relaxed">{item}</p>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </section>
  );
}
