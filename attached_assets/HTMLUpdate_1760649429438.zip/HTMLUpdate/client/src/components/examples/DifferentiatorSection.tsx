import DifferentiatorSection from '../DifferentiatorSection';

export default function DifferentiatorSectionExample() {
  return <DifferentiatorSection language="es" />;
}
