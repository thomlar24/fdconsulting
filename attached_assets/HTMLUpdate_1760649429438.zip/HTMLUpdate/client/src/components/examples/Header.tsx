import { useState } from 'react';
import Header from '../Header';

export default function HeaderExample() {
  const [language, setLanguage] = useState<'es' | 'en'>('es');
  const [darkMode, setDarkMode] = useState(false);

  return (
    <Header
      language={language}
      onLanguageChange={setLanguage}
      darkMode={darkMode}
      onDarkModeToggle={() => setDarkMode(!darkMode)}
    />
  );
}
