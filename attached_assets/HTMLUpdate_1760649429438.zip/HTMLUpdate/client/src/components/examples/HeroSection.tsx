import HeroSection from '../HeroSection';

export default function HeroSectionExample() {
  return (
    <HeroSection
      language="es"
      onContactClick={() => console.log('Contact clicked')}
    />
  );
}
