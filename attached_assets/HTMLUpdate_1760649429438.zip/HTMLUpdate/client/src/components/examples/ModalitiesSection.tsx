import ModalitiesSection from '../ModalitiesSection';

export default function ModalitiesSectionExample() {
  return <ModalitiesSection language="es" />;
}
