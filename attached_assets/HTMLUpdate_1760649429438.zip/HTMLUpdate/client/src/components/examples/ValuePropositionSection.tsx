import ValuePropositionSection from '../ValuePropositionSection';

export default function ValuePropositionSectionExample() {
  return <ValuePropositionSection language="es" />;
}
