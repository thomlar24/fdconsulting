import ServiceCard from '../ServiceCard';
import { BarChart3 } from 'lucide-react';

export default function ServiceCardExample() {
  return (
    <div className="p-8">
      <ServiceCard
        icon={BarChart3}
        title="Data Analysis"
        items={[
          'Advanced statistical analysis',
          'Predictive modeling',
          'Data visualization dashboards',
          'Business intelligence reports'
        ]}
      />
    </div>
  );
}
