import WhoWeAreSection from '../WhoWeAreSection';

export default function WhoWeAreSectionExample() {
  return <WhoWeAreSection language="es" />;
}
