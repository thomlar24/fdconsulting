import { Card } from '@/components/ui/card';
import { Users, Video, FileText } from 'lucide-react';

interface ModalitiesSectionProps {
  language: 'es' | 'en';
}

export default function ModalitiesSection({ language }: ModalitiesSectionProps) {
  const content = {
    es: {
      title: 'Modalidades de Consultoría',
      modalities: [
        {
          icon: Users,
          title: 'Presencial',
          description: 'Trabajo directo en sus instalaciones para un acompañamiento cercano'
        },
        {
          icon: Video,
          title: 'Virtual',
          description: 'Consultoría remota mediante plataformas digitales seguras'
        },
        {
          icon: FileText,
          title: 'Híbrida',
          description: 'Combinación de sesiones presenciales y virtuales según necesidad'
        }
      ]
    },
    en: {
      title: 'Consulting Modalities',
      modalities: [
        {
          icon: Users,
          title: 'On-site',
          description: 'Direct work at your facilities for close support'
        },
        {
          icon: Video,
          title: 'Virtual',
          description: 'Remote consulting through secure digital platforms'
        },
        {
          icon: FileText,
          title: 'Hybrid',
          description: 'Combination of on-site and virtual sessions as needed'
        }
      ]
    }
  };

  const t = content[language];

  return (
    <section className="py-20 border-b border-border">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground" data-testid="text-modalities-title">
          {t.title}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {t.modalities.map((modality, index) => (
            <Card key={index} className="p-8 text-center hover:-translate-y-1 transition-transform duration-300" data-testid={`card-modality-${index}`}>
              <div className="flex justify-center mb-4">
                <modality.icon className="h-16 w-16 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-foreground">{modality.title}</h3>
              <p className="text-muted-foreground">{modality.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
