import { Linkedin, Mail } from 'lucide-react';
import logoImage from '@assets/9F3EFB34-62E7-49B1-98C6-0DAA78859CA4_1760555172363.png';

interface FooterProps {
  language: 'es' | 'en';
}

export default function Footer({ language }: FooterProps) {
  const content = {
    es: {
      company: 'Financial & Data Consulting',
      description: 'Transformando datos en decisiones estratégicas',
      quickLinks: 'Enlaces Rápidos',
      services: 'Servicios',
      contact: 'Contacto',
      copyright: '© 2025 Financial & Data Consulting. Todos los derechos reservados.',
      links: [
        { name: 'Quiénes Somos', id: 'who-we-are' },
        { name: 'Servicios', id: 'services' },
        { name: 'Contacto', id: 'contact' }
      ]
    },
    en: {
      company: 'Financial & Data Consulting',
      description: 'Transforming data into strategic decisions',
      quickLinks: 'Quick Links',
      services: 'Services',
      contact: 'Contact',
      copyright: '© 2025 Financial & Data Consulting. All rights reserved.',
      links: [
        { name: 'About Us', id: 'who-we-are' },
        { name: 'Services', id: 'services' },
        { name: 'Contact', id: 'contact' }
      ]
    }
  };

  const t = content[language];

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-card border-t border-card-border py-12">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <img 
              src={logoImage} 
              alt="Financial & Data Consulting" 
              className="h-24 w-auto mb-4"
            />
            <p className="text-muted-foreground mb-4">{t.description}</p>
            <div className="flex gap-4">
              <a 
                href="https://linkedin.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="hover-elevate p-2 rounded-md"
                data-testid="link-footer-linkedin"
              >
                <Linkedin className="h-5 w-5 text-primary" />
              </a>
              <a 
                href="mailto:team.fdconsulting@gmail.com"
                className="hover-elevate p-2 rounded-md"
                data-testid="link-footer-email"
              >
                <Mail className="h-5 w-5 text-primary" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-foreground mb-4">{t.quickLinks}</h3>
            <ul className="space-y-2">
              {t.links.map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => scrollToSection(link.id)}
                    className="text-muted-foreground hover:text-primary transition-colors"
                    data-testid={`link-footer-${link.id}`}
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-foreground mb-4">{t.contact}</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li data-testid="text-footer-location">Pereira, Risaralda</li>
              <li data-testid="text-footer-country">Colombia</li>
              <li>
                <a href="mailto:team.fdconsulting@gmail.com" className="hover:text-primary transition-colors">
                  team.fdconsulting@gmail.com
                </a>
              </li>
              <li>
                <a href="tel:+573127484606" className="hover:text-primary transition-colors">
                  +57 312 7484606
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
          <p data-testid="text-footer-copyright">{t.copyright}</p>
        </div>
      </div>
    </footer>
  );
}
