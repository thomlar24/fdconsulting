import { BarChart3, Calculator, CheckCircle2 } from 'lucide-react';
import ServiceCard from './ServiceCard';

interface ServicesSectionProps {
  language: 'es' | 'en';
}

export default function ServicesSection({ language }: ServicesSectionProps) {
  const content = {
    es: {
      title: 'Nuestros Servicios',
      services: [
        {
          icon: BarChart3,
          title: 'Consultoría en Análisis de Datos',
          items: [
            'Análisis estadístico avanzado',
            'Modelado predictivo y machine learning',
            'Visualización de datos e informes ejecutivos',
            'Business Intelligence y dashboards interactivos'
          ]
        },
        {
          icon: Calculator,
          title: 'Consultoría Contable y Financiera',
          items: [
            'Análisis financiero y diagnóstico empresarial',
            'Optimización de procesos contables',
            'Implementación de sistemas de costeo',
            'Asesoría en cumplimiento normativo'
          ]
        },
        {
          icon: CheckCircle2,
          title: 'Consultoría en Gestión de Calidad',
          items: [
            'Implementación de sistemas de gestión ISO',
            'Auditorías de calidad y mejora continua',
            'Mapeo y optimización de procesos',
            'Capacitación en estándares de calidad'
          ]
        }
      ]
    },
    en: {
      title: 'Our Services',
      services: [
        {
          icon: BarChart3,
          title: 'Data Analysis Consulting',
          items: [
            'Advanced statistical analysis',
            'Predictive modeling and machine learning',
            'Data visualization and executive reports',
            'Business Intelligence and interactive dashboards'
          ]
        },
        {
          icon: Calculator,
          title: 'Accounting & Financial Consulting',
          items: [
            'Financial analysis and business diagnostics',
            'Accounting process optimization',
            'Costing system implementation',
            'Regulatory compliance advisory'
          ]
        },
        {
          icon: CheckCircle2,
          title: 'Quality Management Consulting',
          items: [
            'ISO management system implementation',
            'Quality audits and continuous improvement',
            'Process mapping and optimization',
            'Quality standards training'
          ]
        }
      ]
    }
  };

  const t = content[language];

  return (
    <section id="services" className="py-20 bg-secondary/20 border-b border-border">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground" data-testid="text-services-title">
          {t.title}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {t.services.map((service, index) => (
            <ServiceCard
              key={index}
              icon={service.icon}
              title={service.title}
              items={service.items}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
