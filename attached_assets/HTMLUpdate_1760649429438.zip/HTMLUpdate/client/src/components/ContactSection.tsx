import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Mail, Phone, MapPin, Send } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ContactSectionProps {
  language: 'es' | 'en';
}

export default function ContactSection({ language }: ContactSectionProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const { toast } = useToast();

  const content = {
    es: {
      title: 'Contáctenos',
      form: {
        name: 'Nombre',
        email: 'Correo Electrónico',
        message: 'Mensaje',
        submit: 'Enviar Mensaje'
      },
      info: {
        email: 'team.fdconsulting@gmail.com',
        phones: ['+57 312 7484606', '+57 310 2461590', '+57 304 4126727'],
        location: 'Pereira, Risaralda, Colombia'
      },
      successMessage: 'Mensaje enviado correctamente',
      successDescription: 'Nos pondremos en contacto pronto'
    },
    en: {
      title: 'Contact Us',
      form: {
        name: 'Name',
        email: 'Email',
        message: 'Message',
        submit: 'Send Message'
      },
      info: {
        email: 'team.fdconsulting@gmail.com',
        phones: ['+57 312 7484606', '+57 310 2461590', '+57 304 4126727'],
        location: 'Pereira, Risaralda, Colombia'
      },
      successMessage: 'Message sent successfully',
      successDescription: 'We will contact you soon'
    }
  };

  const t = content[language];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    
    toast({
      title: t.successMessage,
      description: t.successDescription,
    });

    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <section id="contact" className="py-20">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground" data-testid="text-contact-title">
          {t.title}
        </h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          <Card className="p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  {t.form.name}
                </label>
                <Input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  data-testid="input-contact-name"
                  className="w-full"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  {t.form.email}
                </label>
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  data-testid="input-contact-email"
                  className="w-full"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  {t.form.message}
                </label>
                <Textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  required
                  rows={5}
                  data-testid="input-contact-message"
                  className="w-full resize-none"
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full"
                data-testid="button-contact-submit"
              >
                <Send className="mr-2 h-4 w-4" />
                {t.form.submit}
              </Button>
            </form>
          </Card>

          <div className="space-y-6">
            <Card className="p-6 hover-elevate">
              <div className="flex items-start gap-4">
                <Mail className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Email</h3>
                  <a 
                    href={`mailto:${t.info.email}`}
                    className="text-muted-foreground hover:text-primary transition-colors" 
                    data-testid="text-contact-email"
                  >
                    {t.info.email}
                  </a>
                </div>
              </div>
            </Card>

            <Card className="p-6 hover-elevate">
              <div className="flex items-start gap-4">
                <Phone className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-foreground mb-2">{language === 'es' ? 'Teléfonos' : 'Phones'}</h3>
                  <div className="space-y-1">
                    {t.info.phones.map((phone, index) => (
                      <a 
                        key={index}
                        href={`tel:${phone}`}
                        className="block text-muted-foreground hover:text-primary transition-colors" 
                        data-testid={`text-contact-phone-${index}`}
                      >
                        {phone}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-6 hover-elevate">
              <div className="flex items-start gap-4">
                <MapPin className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-foreground mb-1">{language === 'es' ? 'Ubicación' : 'Location'}</h3>
                  <p className="text-muted-foreground" data-testid="text-contact-location">{t.info.location}</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
