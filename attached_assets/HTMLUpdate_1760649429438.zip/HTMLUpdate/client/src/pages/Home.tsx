import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import WhoWeAreSection from '@/components/WhoWeAreSection';
import ServicesSection from '@/components/ServicesSection';
import ModalitiesSection from '@/components/ModalitiesSection';
import ValuePropositionSection from '@/components/ValuePropositionSection';
import DifferentiatorSection from '@/components/DifferentiatorSection';
import ExperienceSection from '@/components/ExperienceSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';

export default function Home() {
  const [language, setLanguage] = useState<'es' | 'en'>('es');
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header
        language={language}
        onLanguageChange={setLanguage}
        darkMode={darkMode}
        onDarkModeToggle={() => setDarkMode(!darkMode)}
      />
      <main>
        <HeroSection language={language} onContactClick={scrollToContact} />
        <WhoWeAreSection language={language} />
        <ServicesSection language={language} />
        <ModalitiesSection language={language} />
        <ValuePropositionSection language={language} />
        <DifferentiatorSection language={language} />
        <ExperienceSection language={language} />
        <ContactSection language={language} />
      </main>
      <Footer language={language} />
    </div>
  );
}
