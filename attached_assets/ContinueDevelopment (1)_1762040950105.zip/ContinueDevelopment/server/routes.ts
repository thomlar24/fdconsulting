import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactMessageSchema } from "@shared/schema";
import nodemailer from "nodemailer";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactMessageSchema.parse(req.body);
      const message = await storage.createContactMessage(validatedData);

      // TODO: Configurar envío de email cuando el usuario proporcione credenciales
      // Por ahora, los mensajes se guardan en memoria
      console.log("New contact message:", message);

      // Si hay credenciales SMTP configuradas, enviar el email
      if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
        try {
          const transporter = nodemailer.createTransport({
            host: process.env.SMTP_HOST,
            port: parseInt(process.env.SMTP_PORT || "587"),
            secure: process.env.SMTP_SECURE === "true",
            auth: {
              user: process.env.SMTP_USER,
              pass: process.env.SMTP_PASS,
            },
          });

          await transporter.sendMail({
            from: process.env.SMTP_USER,
            to: "team.fdconsulting@gmail.com",
            subject: `Nuevo mensaje de contacto de ${validatedData.name}`,
            text: `
Nombre: ${validatedData.name}
Email: ${validatedData.email}

Mensaje:
${validatedData.message}
            `,
            html: `
<h2>Nuevo mensaje de contacto</h2>
<p><strong>Nombre:</strong> ${validatedData.name}</p>
<p><strong>Email:</strong> ${validatedData.email}</p>
<h3>Mensaje:</h3>
<p>${validatedData.message.replace(/\n/g, '<br>')}</p>
            `,
          });

          console.log("Email sent successfully");
        } catch (emailError) {
          console.error("Error sending email:", emailError);
          // No fallar la petición si el email falla
        }
      }

      res.json({ success: true, message });
    } catch (error) {
      console.error("Error processing contact form:", error);
      res.status(400).json({ error: "Invalid request data" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
