import { jsPDF } from 'jspdf';

export function generatePortfolioPDF(language: 'en' | 'es') {
  const doc = new jsPDF();
  
  const primaryColor: [number, number, number] = [33, 54, 89]; // Navy
  const accentColor: [number, number, number] = [198, 146, 77]; // Gold
  
  let yPosition = 20;
  const lineHeight = 7;
  const pageWidth = doc.internal.pageSize.width;
  const margin = 20;
  const contentWidth = pageWidth - (margin * 2);

  // Title
  doc.setFontSize(24);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('Financial & Data Consulting', pageWidth / 2, yPosition, { align: 'center' });
  
  yPosition += 10;
  doc.setFontSize(14);
  doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
  const tagline = language === 'es' 
    ? 'Organizamos sus datos, optimizamos sus procesos'
    : 'We organize your data, we optimize your processes';
  doc.text(tagline, pageWidth / 2, yPosition, { align: 'center' });
  
  yPosition += 15;
  
  // About Us
  doc.setFontSize(16);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(language === 'es' ? 'Quiénes Somos' : 'About Us', margin, yPosition);
  yPosition += 8;
  
  doc.setFontSize(10);
  doc.setTextColor(60, 60, 60);
  const aboutText = language === 'es'
    ? 'Somos un equipo multidisciplinario de profesionales en análisis de datos, contabilidad, gestión de calidad y procesos administrativos. Apoyamos a pequeñas y medianas empresas a organizar su información, optimizar sus procesos y fortalecer su gestión financiera, garantizando el cumplimiento normativo y facilitando decisiones estratégicas basadas en datos.'
    : 'We are a multidisciplinary team of professionals specialized in data analysis, accounting, quality management, and administrative processes. We help small and medium-sized businesses organize their information, optimize processes, and strengthen their financial management, ensuring compliance and enabling data-driven strategic decisions.';
  
  const aboutLines = doc.splitTextToSize(aboutText, contentWidth);
  doc.text(aboutLines, margin, yPosition);
  yPosition += aboutLines.length * lineHeight + 5;

  // Services
  doc.setFontSize(16);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(language === 'es' ? 'Servicios' : 'Services', margin, yPosition);
  yPosition += 8;

  doc.setFontSize(12);
  doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
  doc.text(language === 'es' ? 'Análisis y Gestión de Datos' : 'Data Analysis & Management', margin, yPosition);
  yPosition += 6;

  doc.setFontSize(10);
  doc.setTextColor(60, 60, 60);
  const dataServices = language === 'es' ? [
    'Normalización y depuración de bases de datos',
    'Creación de tableros de control (Power BI, Excel, Google Suite)',
    'Diseño e implementación de indicadores de gestión (KPI)',
    'Consultoría en procesos administrativos y de gestión de calidad'
  ] : [
    'Normalization and cleaning of databases',
    'Dashboard creation (Power BI, Excel, Google Suite)',
    'Design and implementation of performance indicators (KPIs)',
    'Consulting in administrative and quality management processes'
  ];

  dataServices.forEach(service => {
    doc.text(`• ${service}`, margin + 5, yPosition);
    yPosition += lineHeight;
  });
  yPosition += 3;

  doc.setFontSize(12);
  doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
  doc.text(language === 'es' ? 'Contabilidad y Finanzas' : 'Accounting & Finance', margin, yPosition);
  yPosition += 6;

  doc.setFontSize(10);
  doc.setTextColor(60, 60, 60);
  const financeServices = language === 'es' ? [
    'Asesoría contable y financiera integral',
    'Análisis financiero y proyección de resultados',
    'Implementación de controles contables y presupuestales'
  ] : [
    'Comprehensive accounting and financial consulting',
    'Financial analysis and forecasting',
    'Implementation of accounting and budget controls'
  ];

  financeServices.forEach(service => {
    doc.text(`• ${service}`, margin + 5, yPosition);
    yPosition += lineHeight;
  });
  yPosition += 5;

  // Service Models
  doc.setFontSize(16);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(language === 'es' ? 'Modalidades de Trabajo' : 'Service Models', margin, yPosition);
  yPosition += 8;

  doc.setFontSize(12);
  doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
  doc.text(language === 'es' ? 'Proyectos Puntuales' : 'One-time Projects', margin, yPosition);
  yPosition += 6;
  doc.setFontSize(10);
  doc.setTextColor(60, 60, 60);
  const projectExample = language === 'es'
    ? 'Ejemplo: organización de una base de datos para generar reportes confiables.'
    : 'Example: organizing a database to generate reliable reports.';
  doc.text(projectExample, margin + 5, yPosition);
  yPosition += 8;

  doc.setFontSize(12);
  doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
  doc.text(language === 'es' ? 'Acompañamiento Mensual' : 'Monthly Consulting', margin, yPosition);
  yPosition += 6;
  doc.setFontSize(10);
  doc.setTextColor(60, 60, 60);
  const monthlyExample = language === 'es'
    ? 'Ejemplo: soporte continuo en análisis de información y auditorías.'
    : 'Example: ongoing support in data analysis and audits.';
  doc.text(monthlyExample, margin + 5, yPosition);
  yPosition += 10;

  // New page for Value Proposition and Contact
  doc.addPage();
  yPosition = 20;

  // Value Proposition
  doc.setFontSize(16);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(language === 'es' ? 'Nuestro Diferencial' : 'Our Value Proposition', margin, yPosition);
  yPosition += 8;

  doc.setFontSize(10);
  doc.setTextColor(60, 60, 60);
  const values = language === 'es' ? [
    'Atención personalizada',
    'Tarifas flexibles y justas',
    'Experiencia práctica en datos, calidad y finanzas',
    'Enfoque integral entre lo operativo y lo financiero'
  ] : [
    'Personalized attention',
    'Fair and flexible pricing',
    'Hands-on experience in data, quality & finance',
    'Integrated operational & financial approach'
  ];

  values.forEach(value => {
    doc.text(`• ${value}`, margin + 5, yPosition);
    yPosition += lineHeight;
  });
  yPosition += 5;

  // Experience
  doc.setFontSize(16);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(language === 'es' ? 'Experiencia' : 'Experience', margin, yPosition);
  yPosition += 8;

  doc.setFontSize(10);
  doc.setTextColor(60, 60, 60);
  const experiences = language === 'es' ? [
    'Creación de bases de datos y tableros de control para áreas administrativas, contables y operativas.',
    'Implementación de indicadores financieros y de gestión que mejoran la toma de decisiones.',
    'Acompañamiento en procesos de auditoría y cumplimiento normativo.'
  ] : [
    'Development of databases and dashboards for administrative, accounting, and operational areas.',
    'Implementation of financial and management indicators that enhance decision-making.',
    'Support in audit processes and regulatory compliance.'
  ];

  experiences.forEach(exp => {
    const expLines = doc.splitTextToSize(`• ${exp}`, contentWidth - 5);
    doc.text(expLines, margin + 5, yPosition);
    yPosition += expLines.length * lineHeight;
  });
  yPosition += 10;

  // Contact
  doc.setFontSize(16);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text(language === 'es' ? 'Contacto' : 'Contact', margin, yPosition);
  yPosition += 8;

  doc.setFontSize(10);
  doc.setTextColor(60, 60, 60);
  doc.text('Pereira, Colombia', margin, yPosition);
  yPosition += lineHeight;
  doc.text('team.fdconsulting@gmail.com', margin, yPosition);
  yPosition += lineHeight;
  doc.text('+57 310 2461590', margin, yPosition);
  yPosition += lineHeight;
  doc.text('+57 312 7484606', margin, yPosition);
  yPosition += lineHeight;
  doc.text('+57 304 4126727', margin, yPosition);

  // Save the PDF
  const fileName = language === 'es' 
    ? 'F&D_Consulting_Portafolio.pdf'
    : 'F&D_Consulting_Portfolio.pdf';
  doc.save(fileName);
}
