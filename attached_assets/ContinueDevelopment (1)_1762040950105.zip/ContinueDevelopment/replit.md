# Financial & Data Consulting Website

## Project Overview
Professional bilingual (English/Spanish) consulting website for F & D Consulting, a data analysis and financial consulting firm based in Pereira, Colombia.

## Key Features
- Bilingual support (ES/EN) with language toggle
- Dark mode functionality
- Responsive design with gold (#C6924D) and navy (#213659) color scheme
- Contact form with backend integration
- Downloadable PDF portfolio
- All sections: Hero, About, Services, Modalities, Value Proposition, Experience, Contact, Footer

## Tech Stack
- Frontend: React + TypeScript + Vite
- Backend: Express + Node.js
- Styling: Tailwind CSS + shadcn/ui
- Database: In-memory storage (MemStorage)
- PDF Generation: jsPDF
- Email: Nodemailer (requires SMTP configuration)

## Email Configuration
**TODO**: The contact form is functional and saves messages to storage, but email delivery is not yet configured.

To enable email sending to team.fdconsulting@gmail.com, set the following environment secrets:
- `SMTP_HOST` - SMTP server host (e.g., smtp.gmail.com)
- `SMTP_PORT` - SMTP port (usually 587 or 465)
- `SMTP_SECURE` - "true" for port 465, "false" for 587
- `SMTP_USER` - Email account username
- `SMTP_PASS` - Email account password or app-specific password

Alternative: Could use Resend integration (connector:ccfg_resend_01K69QKYK789WN202XSE3QS17V) but user dismissed it.

## Contact Information
- Email: team.fdconsulting@gmail.com
- Phones: +57 310 2461590, +57 312 7484606, +57 304 4126727
- Location: Pereira, Colombia

## Design Guidelines
- Color Scheme: Navy blue (#213659) and Gold (#C6924D)
- Typography: Montserrat font family
- Components: Using shadcn/ui component library
- Logo: Custom logo with chart graphic and "FINANCIAL & DATA CONSULTING" text

## Recent Changes
- Updated all content with real portfolio information
- Implemented contact form with backend API
- Added PDF download functionality
- Integrated custom logo throughout site
